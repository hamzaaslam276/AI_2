import streamlit as st
from utils import preprocess_image, extract_text

st.title("AI-Powered Medical Report Analyzer")

uploaded_file = st.file_uploader("Upload a medical report image", type=["png", "jpg", "jpeg"])
if uploaded_file is not None:
    image = preprocess_image(uploaded_file)
    st.image(image, caption='Uploaded Image', use_column_width=True)
    text = extract_text(image)
    st.subheader("Extracted Text:")
    st.text(text)
