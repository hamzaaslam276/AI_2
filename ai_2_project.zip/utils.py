import cv2
import pytesseract
from PIL import Image
import numpy as np
import streamlit as st

def preprocess_image(uploaded_file):
    image = Image.open(uploaded_file).convert('RGB')
    image = np.array(image)
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    return gray

def extract_text(image):
    return pytesseract.image_to_string(image)
